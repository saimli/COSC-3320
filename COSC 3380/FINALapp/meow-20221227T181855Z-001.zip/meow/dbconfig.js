const config = {
    user: "groupninepos",
    password: "Group9pos",
    server: "groupninpos.database.windows.net",
    database: "group9POS",
    options: {
        enableArithAbort: true,
        encrypt: true
    },
    port: 1433
}

module.exports = config;